from __future__ import print_function, absolute_import, unicode_literals

from fido2.webauthn import PublicKeyCredentialRpEntity
from fido2.client import ClientData
from fido2.server import Fido2Server
from fido2.ctap2 import AttestationObject, AuthenticatorData
from fido2 import cbor
from flask import *
import pickle
import os
import uuid

app = Flask(__name__, static_url_path="")
app.secret_key = b'!dNv\xc9\xb78\x93\x9c\xa7\xd9\xb0~z7Q\x86\xda\xa4\x99\x1f\xbf\xc6~\x8f\xca\x16H\xd9*\x1e\xae'

rp = PublicKeyCredentialRpEntity("localhost", "Mukham passwordless") #("api.mukham.in", "Mukham passwordless")
server = Fido2Server(rp)


# Single user support.
credentials = []

path=''  #'/etc/mukham/keys/'
#sudo chmod -R 777 /etc/mukham/keys

@app.route("/")
def index():
    return redirect("/index.html")

@app.route("/authbegin", methods=["GET","POST"])
def authbegin():
	token=str(uuid.uuid4())
	return render_template('authn.html', token=token)
	
@app.route("/getcred", methods=["GET","POST"])
def getcred():
	tok1=request.args.get('token')
	tok2=read_token()
	if tok1==tok2:
		save_token('')
		return "akash.19bcn7108@vitap.ac.in$Midhun@123"
	else:
		return ""

@app.route("/api/register/begin", methods=["POST"])
def register_begin():
    credentials=read_key()
    registration_data, state = server.register_begin(
        {
            "id": b"user_id",
            "name": "a_user",
            "displayName": "A. User",
            "icon": "https://example.com/image.png",
        },
        credentials,
        user_verification="discouraged",
        authenticator_attachment="cross-platform",
    )

    session["state"] = state
    print("\n\n\n\n")
    print(registration_data)
    print("\n\n\n\n")
    return cbor.encode(registration_data)

@app.route("/api/register/beginplatform", methods=["POST"])
def register_begin_platform():
    credentials=read_key()
    registration_data, state = server.register_begin(
        {
            "id": b"user_id",
            "name": "a_user",
            "displayName": "A. User",
            "icon": "https://example.com/image.png",
        },
        credentials,
        user_verification="discouraged",
        authenticator_attachment="platform",
    )

    session["state"] = state
    print("\n\n\n\n")
    print(registration_data)
    print("\n\n\n\n")
    return cbor.encode(registration_data)


@app.route("/api/register/complete", methods=["GET","POST"])
def register_complete():
    credentials=read_key()

    data = cbor.decode(request.get_data())
    client_data = ClientData(data["clientDataJSON"])
    att_obj = AttestationObject(data["attestationObject"])
    print("clientData", client_data)
    print("AttestationObject:", att_obj)

    auth_data = server.register_complete(session["state"], client_data, att_obj)

    credentials.append(auth_data.credential_data)
    save_key(credentials)
    print("REGISTERED CREDENTIAL:", auth_data.credential_data)
    return cbor.encode({"status": "OK"})


@app.route("/api/authenticate/begin", methods=["POST"])
def authenticate_begin():
    credentials=read_key()
    if not credentials:
        abort(404)

    auth_data, state = server.authenticate_begin(credentials)
    session["state"] = state
    return cbor.encode(auth_data)


@app.route("/api/authenticate/complete", methods=["GET","POST"])
def authenticate_complete():
    credentials=read_key()
    token=request.args.get('token')
    if not credentials:
        abort(404)

    data = cbor.decode(request.get_data())
    credential_id = data["credentialId"]
    client_data = ClientData(data["clientDataJSON"])
    auth_data = AuthenticatorData(data["authenticatorData"])
    signature = data["signature"]
    print("clientData", client_data)
    print("AuthenticatorData", auth_data)

    server.authenticate_complete(
        session.pop("state"),
        credentials,
        credential_id,
        client_data,
        auth_data,
        signature,
    )
    print("ASSERTION OK")
    save_token(token)
    return cbor.encode({"status": "OK"})

def save_key(credentials):
	with open(path+'datafilekey.pkl','wb') as outp1:
		pickle.dump(credentials,outp1,pickle.HIGHEST_PROTOCOL)
		
def read_key():
	try:
		with open(path+'datafilekey.pkl', 'rb') as inp:
			temp = pickle.load(inp)
			return temp
	except:
		print("no cred data")
		return []

def save_token(token):
	outp1=open(path+'token.pkl','w')
	outp1.write(token)
	outp1.close()

def read_token():
	try:
		f = open(path+"token.pkl", "r")
		k=f.read()
		f.close()
	except:
		return ''
	return k

if __name__ == "__main__":
    app.run(ssl_context="adhoc", host='0.0.0.0', debug=False)
