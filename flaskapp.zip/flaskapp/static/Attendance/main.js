function retrieveusers(){
    document.getElementById("tb1").innerHTML="";
    document.getElementById("th1").innerHTML="";
    
    var count=1;
    var fdate=document.getElementById("fdate").value;
    var tdate=document.getElementById("tdate").value;

    var school=document.getElementById("school").value;
    var year=document.getElementById("year").value;
    var month=document.getElementById("month").value;

    if(parseInt(fdate)>parseInt(tdate)){
        alert("From and To dates are incorrect")
    }else{
        var theader=document.getElementById("th1");
        var trow=document.createElement('tr');
        var th0=document.createElement('th');
        var th1=document.createElement('th');
        var th2=document.createElement('th');
        var th3=document.createElement('th');
        var th4=document.createElement('th');
        var th5=document.createElement('th');
        var th6=document.createElement('th');
        th0.innerHTML="S.NO"
        th1.innerHTML="Id"
        th2.innerHTML="Email"
        th3.innerHTML="Name"
        th4.innerHTML="Department"
        th5.innerHTML="Last Updated On"
        th6.innerHTML="Percentage"
        th0.style.backgroundColor="#87AFC6"
        th1.style.backgroundColor="#87AFC6"
        th2.style.backgroundColor="#87AFC6"
        th3.style.backgroundColor="#87AFC6"
        th4.style.backgroundColor="#87AFC6"
        th5.style.backgroundColor="#87AFC6"
        th6.style.backgroundColor="#87AFC6"
        trow.appendChild(th0)
        trow.appendChild(th1)
        trow.appendChild(th2)
        trow.appendChild(th3)
        trow.appendChild(th4)
        trow.appendChild(th5)
        trow.appendChild(th6)
        var months=["January","February","March","April","May","June","July","August","September","October","November","December"]

        for (let i = parseInt(fdate); i <= parseInt(tdate); i++) {
            var th=document.createElement('th');
            th.innerHTML=i+"-"+(months.indexOf(month)+1)+"-"+year;
            th.style.backgroundColor="#87AFC6"
            trow.appendChild(th)
        }
        theader.appendChild(trow)
        if(school.localeCompare("ALL")==0){
            var docRef = db.collection('Users')
            docRef.get().then(snapshot => {
                document.getElementById("count").innerHTML="Total Students: "+snapshot.size
                snapshot.forEach(doc => {
                    docRef.doc(doc.id).get().then(doc => {
                        var tbody=document.getElementById("tb1");
                        var trow=document.createElement('tr');
                        var td0=document.createElement('td');
                        var td1=document.createElement('td');
                        var td2=document.createElement('td');
                        var td3=document.createElement('td');
                        var td4=document.createElement('td');
                        var td5=document.createElement('td');
                        var td6=document.createElement('td');
                        document.getElementById("percent").innerHTML="Uploaded: "+((count++)/snapshot.size)*100+"%"
                        td0.innerHTML=count-1;
                        td1.innerHTML=doc.data().EmpId;
                        td2.innerHTML=doc.data().email;
                        td3.innerHTML=doc.data().fullName;
                        td4.innerHTML=doc.data().school;
                        trow.appendChild(td0);
                        trow.appendChild(td1);
                        trow.appendChild(td2);
                        trow.appendChild(td3);
                        trow.appendChild(td4);
                        const usersRef = db.collection("AttendanceData").doc(doc.id)
                        usersRef.get().then((docSnapshot) => {
                            if (docSnapshot.exists) {
                                var docRef2 = db.collection("AttendanceData").doc(doc.id).collection("Years").doc(year).collection("Months").doc(month)
                                docRef2.get().then(doc2 =>{
                                    var count=0,days=0;
                                    for (let i = parseInt(fdate); i <= parseInt(tdate); i++) {
                                        var td=document.createElement('td');
                                        td.style.color="white"
                                        var data=doc2.data().Attendance[parseInt(i)-1]
                                        days=days+1;
                                        if(data=="P"){
                                            count=count+2;
                                            td.innerHTML="P"
                                            td.style.backgroundColor="green"
                                        }else if(data=="A"){
                                            td.innerHTML="A"
                                            td.style.backgroundColor="red"
                                        }else if(data=="FN"){
                                            count=count+1;
                                            td.innerHTML="FN"
                                            td.style.backgroundColor="orange"
                                        }else if(data=="AN"){
                                            count=count+1;
                                            td.innerHTML="AN"
                                            td.style.backgroundColor="brown"
                                        }else if(data=="H"){
                                            td.innerHTML="N"
                                            td.style.backgroundColor="blue"
                                            days=days-1;
                                        }
                                        trow.appendChild(td)
                                    }
                                    td5.innerHTML=doc2.data().Last_Updated_on;
                                    let num=count*100/(days*2)
                                    td6.innerHTML=num.toFixed(2)+"%"
                                })
                            } else {
                                for (let i = parseInt(fdate); i <= parseInt(tdate); i++) {
                                    var td=document.createElement('td');                                            
                                    td.innerHTML="-"
                                    trow.appendChild(td)
                                }
                                td5.innerHTML="-";
                                td6.innerHTML="-";
                            }
                        });
                        trow.appendChild(td5);
                        trow.appendChild(td6);
                        tbody.appendChild(trow);
                    })
                })
            })
        }else{
            var docRef = db.collection("Users").where("school", "==", school)
            docRef.get().then(snapshot => {
                document.getElementById("count").innerHTML="Total Students: "+snapshot.size
                snapshot.forEach(doc => {
                    var tbody=document.getElementById("tb1");
                    var trow=document.createElement('tr');
                    var td0=document.createElement('td');
                    var td1=document.createElement('td');
                    var td2=document.createElement('td');
                    var td3=document.createElement('td');
                    var td4=document.createElement('td');
                    var td5=document.createElement('td');
                    var td6=document.createElement('td');
                    document.getElementById("percent").innerHTML="Uploaded: "+((count++)/snapshot.size)*100+"%"
                    td0.innerHTML=count-1;
                    td1.innerHTML=doc.data().EmpId;
                    td2.innerHTML=doc.data().email;
                    td3.innerHTML=doc.data().fullName;
                    td4.innerHTML=doc.data().school;
                    trow.appendChild(td0);
                    trow.appendChild(td1);
                    trow.appendChild(td2);
                    trow.appendChild(td3);
                    trow.appendChild(td4);
                    const usersRef = db.collection("AttendanceData").doc(doc.id)
                    usersRef.get().then((docSnapshot) => {
                        if (docSnapshot.exists) {
                            var docRef2 = db.collection("AttendanceData").doc(doc.id).collection("Years").doc(year).collection("Months").doc(month)
                            docRef2.get().then(doc2 =>{
                                var count=0,days=0;
                                for (let i = parseInt(fdate); i <= parseInt(tdate); i++) {
                                    var td=document.createElement('td');
                                    td.style.color="white"
                                    var data=doc2.data().Attendance[parseInt(i)-1]
                                    days=days+1;
                                    if(data=="P"){
                                        count=count+2;
                                        td.innerHTML="P"
                                        td.style.backgroundColor="green"
                                    }else if(data=="A"){
                                        td.innerHTML="A"
                                        td.style.backgroundColor="red"
                                    }else if(data=="FN"){
                                        count=count+1;
                                        td.innerHTML="FN"
                                        td.style.backgroundColor="orange"
                                    }else if(data=="AN"){
                                        count=count+1;
                                        td.innerHTML="AN"
                                        td.style.backgroundColor="brown"
                                    }else if(data=="H"){
                                        td.innerHTML="N"
                                        td.style.backgroundColor="blue"
                                        days=days-1;
                                    }
                                    trow.appendChild(td)
                                }
                                td5.innerHTML=doc2.data().Last_Updated_on;
                                let num=count*100/(days*2)
                                td6.innerHTML=num.toFixed(2)+"%"
                            })
                        } else {
                            for (let i = parseInt(fdate); i <= parseInt(tdate); i++) {
                                var td=document.createElement('td');                                            
                                td.innerHTML="-"
                                trow.appendChild(td)
                            }
                            td5.innerHTML="-";
                            td6.innerHTML="-";
                        }
                    });
                    
                    trow.appendChild(td5);
                    trow.appendChild(td6);
                    tbody.appendChild(trow);
                })
            })
        }
    }
}

function tableToExcel () {
    var uri = 'data:application/vnd.ms-excel;base64,',template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><meta http-equiv="content-type" content="application/vnd.ms-excel; charset=UTF-8"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>', base64 = function (s) {
            return window.btoa(unescape(encodeURIComponent(s)))
        }, format = function (s, c) {
            return s.replace(/{(\w+)}/g, function (m, p) {
                return c[p];
            })
        }
    if (!table.nodeType) table = document.getElementById('table')
    var ctx = {worksheet: 'Worksheet', table: table.innerHTML}
    var a = document.createElement('a');
    a.href = uri + base64(format(template, ctx))
    a.download = 'AttendanceData.xls';
    a.click();
}