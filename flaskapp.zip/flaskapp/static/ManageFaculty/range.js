
let container=document.getElementsByClassName("range-slider")[0]
let slider=document.getElementById("sliderS")
let thumb=document.getElementsByClassName("slider-thumb")[0]
let tooltip=document.getElementById("tooltip")
let progress=document.getElementById("progessBar")

let m_100=document.getElementById("100m")
let m_250=document.getElementById("250m")
let m_500=document.getElementById("500m")
let m_750=document.getElementById("750m")
let km_1=document.getElementById("1km")
let m_100_text=document.getElementById("100m_text")
let m_250_text=document.getElementById("250m_text")
let m_500_text=document.getElementById("500m_text")
let m_750_text=document.getElementById("750m_text")
let km_1_text=document.getElementById("1km_text")

function Slides(){
    let max=slider.getAttribute("max")
    let val=(slider.value/max)*100+"%"
    tooltip.innerHTML=slider.value
    progress.style.width=val;
    thumb.style.left=val;
    m_100.style.left=(100/max)*100+"%"
    m_250.style.left=(250/max)*100+"%"
    m_500.style.left=(500/max)*100+"%"
    m_750.style.left=(750/max)*100+"%"
    km_1.style.left=(1000/max)*100+"%"
    m_100_text.style.left=(100/max)*100+"%"
    m_250_text.style.left=(250/max)*100+"%"
    m_500_text.style.left=(500/max)*100+"%"
    m_750_text.style.left=(750/max)*100+"%"
    km_1_text.style.left=(1000/max)*100+"%"
  
}
Slides()

slider.addEventListener("input",()=>{
    Slides()
})

