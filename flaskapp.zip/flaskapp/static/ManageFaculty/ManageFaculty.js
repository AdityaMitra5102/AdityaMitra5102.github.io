let first=document.getElementById("first")
let second=document.getElementById("second")
second.style.height=first.clientHeight+"px"
let percent=""
let centerDoughnutPlugin = {
    id: "annotateDoughnutCenter",
    afterDraw: (chart) => {
        let width = chart.width;
        let height = chart.height;
        let ctx = chart.ctx;

        ctx.restore();
        let fontSize = (height / 130).toFixed(2);
        ctx.font = "1.5" + "em sans-serif";
        ctx.textBaseline = "middle";
        //let text = document.getElementById("edit_eid").innerHTML;
        let text = percent;
        let textX = Math.round((width - ctx.measureText(text).width) / 2);
        let textY = height / 1.8;
        ctx.fillText(text, textX, textY);
        ctx.save();
    },
};


const ctx2 = document.getElementById('myChart2').getContext('2d');
const myChart2 = new Chart(ctx2, {
    type: 'doughnut',
    data: {
        labels: [
            'Attended',
            'Not Attended',
        ],
        datasets: [{
            label: 'My First Dataset',
            borderWidth:2,
            data: [],
            backgroundColor: [
                'rgba(46, 49, 146, 1)',
                'rgba(136, 191, 222, 1)',
            ],
            hoverOffset: 2
        }]
        
    },
    options: {
        maintainAspectRatio: false,
        cutout: "85%",
    },
    plugins: [centerDoughnutPlugin]
});

function Edit_Faculty(i){
    let hidden=document.getElementsByClassName("OverLay")[0];
    hidden.classList.toggle("Over_active")
    let name=document.getElementById("f_name")
    let e_id=document.getElementById("e_id")
    if(i==0){
        name.value=document.getElementById("edit_name").innerHTML
        e_id.value=document.getElementById("edit_eid").innerHTML
    }
    if(i==1){
        var usersRef = db.collection("Users").doc(localStorage.getItem("authid"));
         usersRef.update({
            "fullName":name.value,
            "EmpId":e_id.value
        }).then(() => {
            alert("Changes are Updated Successfully");
            window.location.href="ManageFaculty.html";
        })
    }
}

function ToggelBtn(){
    let button =document.getElementById("disable-Btn");
    let edit=document.getElementById("editIcon")
    let text=document.getElementById("texthidden")
    button.classList.toggle("btn_active")
    button.innerHTML=(button.innerHTML==="Enable account"?"Disable account":"Enable account")
    if(button.innerHTML==="Enable account"){
        edit.style.display="none";
        text.style.display="block";
    }
    if(button.innerHTML==="Disable account"){
        edit.style.display="unset";
        text.style.display="none";
    }
}
const toTimestamp = (strDate) => {  
    const dt = new Date(strDate).getTime();  
    return dt / 1000;  
}  
async function details(){
    document.getElementById("tbdata").innerHTML="";
    var fdate=document.getElementById("fdate").value;
    var tdate=document.getElementById("tdate").value;
    var year=document.getElementById("year").value;
    var month=document.getElementById("month").value;

    if(parseInt(fdate)>parseInt(tdate)){
        alert("From and To dates are incorrect")
    }else{
        var count=1;
        var present=0;
        var montharr= ["January","February","March","April","May","June","July","August","September","October","November","December"];
        var docids=[];
        var docRef = db.collection('AttendanceData').doc(localStorage.getItem("authid"))
        docRef.get().then((doc) => {
            var m=parseInt(montharr.indexOf(month))+1
            for (var i=parseInt(fdate);i<=parseInt(tdate);i++) {
                // console.log("entered")
                if(i.toString().length==1){
                    var d="0"+i;
                }else{
                    var d=i
                }
                if(m.toString().length==1){
                    var m="0"+m;
                }
                var docid=d+"-"+m+"-"+year
                docids.push(docid);
                var docRef=db.collection('AttendanceData').doc(localStorage.getItem("authid")).collection('Years').doc(year).collection('Months').doc(month).collection('Days').doc(docid)
                docRef.get().then((doc) => {
                    var tbody=document.getElementById("tbdata");
                    var trow=document.createElement('tr');
                    var td0=document.createElement('td');
                    var td1=document.createElement('td');
                    var td2=document.createElement('td');
                    var td3=document.createElement('td');
                    var td4=document.createElement('td');
                    var td5=document.createElement('td');
                    var td6=document.createElement('td');
                    var td7=document.createElement('td');
                    td0.innerHTML=count++;
                    td1.innerHTML=docids[count-2];
                    td2.innerHTML="2";
                    
                    if (doc.exists) {
                        var val=doc.id;
                        if(doc.data()[val][0]==false){
                            td3.innerHTML="Absent";
                            td4.innerHTML="<span class='material-icons'> &#xE3C9;</span>"
                        }else{
                            var value=String(doc.data()[val][0].toDate())
                            td3.innerHTML=value.split(" ")[4];
                            td4.innerHTML=""
                            present++;
                        }
                        if(doc.data()[val][1]==false){
                            td5.innerHTML="Absent";
                            td6.innerHTML="<span class='material-icons'> &#xE3C9;</span>"
                        }else{
                            var value=String(doc.data()[val][1].toDate())
                            td5.innerHTML=value.split(" ")[4];
                            td6.innerHTML=""
                            present++;
                        }
                    }else{
                        td3.innerHTML="Absent";
                        td4.innerHTML="<span class='material-icons'> &#xE3C9;</span>"
                        td5.innerHTML="Absent";
                        td6.innerHTML="<span class='material-icons'> &#xE3C9;</span>"
                    }
                    td7.innerHTML="<button>Update</button>"
                    td7.style.visibility="hidden";
                    td4.onclick=function(){
                        if(td3.innerHTML=="Absent"){
                            td3.contentEditable=true;
                            td3.innerHTML="00:00:00"
                            td3.style.border="1px solid black";
                            td4.style.visibility="hidden";
                            td7.style.visibility="visible";
                        }
                    }
                    td6.onclick=function(){
                        if(td5.innerHTML=="Absent"){
                            td5.contentEditable=true;
                            td5.innerHTML="00:00:00"
                            td5.style.border="1px solid black";
                            td6.style.visibility="hidden";
                            td7.style.visibility="visible";
                        }
                    }
                    td7.onclick=function(){
                        var docupdate=db.collection('AttendanceData').doc(localStorage.getItem("authid")).collection('Years').doc(year).collection('Months').doc(month).collection('Days').doc(td1.innerHTML)
                        var document=docupdate.id
                        if(td3.innerHTML=="Absent" || td3.innerHTML=="00:00:00"){
                            var val1=false
                        }else{
                            var val1=m+"-"+td1.innerHTML.split("-")[0]+"-"+year+" "+td3.innerHTML;
                            val1=val1.toString()
                            val1=new Date(val1)
                            val1.toLocaleString('en-GB')
                            val1=firebase.firestore.Timestamp.fromDate(new Date(val1))
                        }
                        if(td5.innerHTML=="Absent" || td5.innerHTML=="00:00:00"){
                            var val2=false
                        }else{
                            var val2=m+"-"+td1.innerHTML.split("-")[0]+"-"+year+" "+td5.innerHTML;
                            val2=val2.toString()
                            val2=new Date(val2)
                            val2.toLocaleString('en-GB')
                            val2=firebase.firestore.Timestamp.fromDate(new Date(val2))
                        }
                        if(val1==false && val2==false){
                            var result="A";
                        }else if(val1!=false && val2==false){
                            var result="FN"
                        }else if(val1==false && val2!=false){
                            var result="AN"
                        }else{
                            var result="P"
                        }
                        if(val1!=false || val2!=false){
                            var docData = {
                                [document]: [val1,val2]
                            };
                            var arrupdate=db.collection('AttendanceData').doc(localStorage.getItem("authid")).collection('Years').doc(year).collection('Months').doc(month)
                            arrupdate.get().then((arrdoc) => {
                                var docexists=false;
                                if(arrdoc.exists){
                                    docexists=true
                                }
                                docupdate.set(docData,{merge: true}).then(() => {
                                    var updatedate=td1.innerHTML.split("-")[0]
                                    if(docexists==true){
                                        var objects = arrdoc.data().Attendance
                                        objects[parseInt(updatedate)-1]=result
                                        arrupdate.update({
                                            Attendance:objects
                                        }).then(()=>{
                                            details()
                                        })
                                    }else{
                                        var numdays=new Date(parseInt(year), parseInt(m), 0).getDate();
                                        var objects=Array(parseInt(numdays)).fill("A");
                                        objects[parseInt(updatedate)-1]=result
                                        arrupdate.set({
                                            Attendance:objects
                                        }).then(()=>{
                                            details()
                                        })
                                    }
                                })
                            })
                        } 
                    }
                    trow.appendChild(td0);
                    trow.appendChild(td1);
                    trow.appendChild(td2);
                    trow.appendChild(td3);
                    trow.appendChild(td4);
                    trow.appendChild(td5);
                    trow.appendChild(td6);
                    trow.appendChild(td7);
                    tbody.appendChild(trow);
                }).then(()=>{
                    var days=parseInt(tdate)-parseInt(fdate)+1;
                    percent=(present*100)/(2*days);
                    percent=percent.toFixed(2)+"%";
                    myChart2.data.datasets[0].data[0]=present;
                    myChart2.data.datasets[0].data[1]=2*days-present;
                    myChart2.update();
                })
            }
        })
    }
}
function edit(){
    let inputs=document.getElementsByClassName('input');
    for(i of inputs){
        i.readOnly=false;
        i.style.border="1px solid black";
    }
    document.getElementById("update").style.display="block";
    document.getElementById("edit").style.display="none";
}

function daysInMonth (month, year) {
    return new Date(year, month, 0).getDate();
}