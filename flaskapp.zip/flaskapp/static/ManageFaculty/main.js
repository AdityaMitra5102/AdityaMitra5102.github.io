async function retrieveusers(i){
    if(i==0){
        document.getElementById("tb1").innerHTML="";
        count=0;
        latest=1;
    }
    var id=document.getElementById("id").value;
    var school=document.getElementById("school").value;
    if(id.localeCompare("")!=0){
        if(id.split("@").length==1){
            id=id.toUpperCase();
            document.getElementById("load").style.visibility="hidden"
            var docRef = db.collection('Users').where("EmpId","==",id);
            docRef.get().then(snapshot => {
                document.getElementById("count").innerHTML=" ";
                if(snapshot.size==1){
                    document.getElementById("id").value="";
                    snapshot.forEach(doc => {
                        var tbody=document.getElementById("tb1");
                        var trow=document.createElement('tr');
                        var td0=document.createElement('td');
                        var td7=document.createElement('td');
                        var td1=document.createElement('td');
                        var td2=document.createElement('td');
                        var td3=document.createElement('td');
                        var td4=document.createElement('td');
                        var td5=document.createElement('td');
                        var td6=document.createElement('td');
                        td0.innerHTML="1";
                        td1.innerHTML=doc.data().EmpId;
                        td2.innerHTML=doc.data().fullName;
                        td3.innerHTML=doc.data().school;
                        td4.innerHTML=doc.data().email;
                        td5.innerHTML=doc.data().entryCount;
                        td6.innerHTML="<button>View More</button>";
                        td6.onclick=function(){
                            localStorage.setItem("authid",doc.id);
                            window.location.href="ManageFaculty.html";
                        }
                        trow.appendChild(td0);
                        trow.appendChild(td1);
                        trow.appendChild(td2);
                        trow.appendChild(td3);
                        trow.appendChild(td4);
                        trow.appendChild(td5);
                        trow.appendChild(td6);
                        tbody.appendChild(trow);
                    });
                }else{
                    document.getElementById("count").innerHTML="ID doesn't exist";
                    document.getElementById("id").focus();
                }
                document.getElementById("id").innerHTML=" "
            });
        }else if(id.split("@").length==2){
            document.getElementById("load").style.visibility="hidden"
            var docRef = db.collection('Users').where("email","==",id);
            docRef.get().then(snapshot => {
                document.getElementById("count").innerHTML=" ";
                if(snapshot.size==1){
                    document.getElementById("id").value="";
                    snapshot.forEach(doc => {
                        var tbody=document.getElementById("tb1");
                        var trow=document.createElement('tr');
                        var td0=document.createElement('td');
                        var td1=document.createElement('td');
                        var td2=document.createElement('td');
                        var td3=document.createElement('td');
                        var td4=document.createElement('td');
                        var td5=document.createElement('td');
                        var td6=document.createElement('td');
                        td0.innerHTML="1";
                        td1.innerHTML=doc.data().EmpId;
                        td2.innerHTML=doc.data().fullName;
                        td3.innerHTML=doc.data().school;
                        td4.innerHTML=doc.data().email;
                        td5.innerHTML=doc.data().entryCount;
                        td6.innerHTML="<button>View More</button>";
                        td6.onclick=function(){
                            localStorage.setItem("authid",doc.id);
                            window.location.href="ManageFaculty.html";
                        }
                        trow.appendChild(td0);
                        trow.appendChild(td1);
                        trow.appendChild(td2);
                        trow.appendChild(td3);
                        trow.appendChild(td4);
                        trow.appendChild(td5);
                        trow.appendChild(td6);
                        tbody.appendChild(trow);
                    });
                }else{
                    document.getElementById("count").innerHTML="ID doesn't exist";
                    document.getElementById("id").focus();
                }
                document.getElementById("id").innerHTML=" "
            });
        }
    }else{
        if(school.localeCompare("ALL")==0){
            var docRef = db.collection('Users').orderBy('entryCount').startAfter(latest || 0).limit(10)
            const data=await docRef.get();
            data.docs.forEach(doc=>{
                var tbody=document.getElementById("tb1");
                var trow=document.createElement('tr');
                var td0=document.createElement('td');
                var td1=document.createElement('td');
                var td2=document.createElement('td');
                var td3=document.createElement('td');
                var td4=document.createElement('td');
                var td5=document.createElement('td');
                var td6=document.createElement('td');
                count++;
                td0.innerHTML=count;
                td1.innerHTML=doc.data().EmpId;
                td2.innerHTML=doc.data().fullName;
                td3.innerHTML=doc.data().school;
                td4.innerHTML=doc.data().email;
                td5.innerHTML=doc.data().entryCount;
                td6.innerHTML="<button>View More</button>";
                td6.onclick=function(){
                    localStorage.setItem("authid",doc.id);
                    window.location.href="ManageFaculty.html";
                }
                trow.appendChild(td0);
                trow.appendChild(td1);
                trow.appendChild(td2);
                trow.appendChild(td3);
                trow.appendChild(td4);
                trow.appendChild(td5);
                trow.appendChild(td6);
                tbody.appendChild(trow);
            })
            document.getElementById("load").style.visibility="visible"
            latest=data.docs[data.docs.length-1]
            if(data.empty){
                document.getElementById("load").style.visibility="hidden"
            }
        }else{
            var docRef = db.collection('Users').where('school','==',school).orderBy('entryCount').startAfter(latest || 0).limit(10)
            document.getElementById("load").style.visibility="visible"
            const data=await docRef.get();
            data.docs.forEach(doc=>{
                var tbody=document.getElementById("tb1");
                var trow=document.createElement('tr');
                var td0=document.createElement('td');
                var td1=document.createElement('td');
                var td2=document.createElement('td');
                var td3=document.createElement('td');
                var td4=document.createElement('td');
                var td5=document.createElement('td');
                var td6=document.createElement('td');
                count++;
                td0.innerHTML=count;
                td1.innerHTML=doc.data().EmpId;
                td2.innerHTML=doc.data().fullName;
                td3.innerHTML=doc.data().school;
                td4.innerHTML=doc.data().email;
                td5.innerHTML=doc.data().entryCount;
                td6.innerHTML="<button>View More</button>";
                td6.onclick=function(){
                    localStorage.setItem("authid",doc.id);
                    window.location.href="ManageFaculty.html";
                }
                trow.appendChild(td0);
                trow.appendChild(td1);
                trow.appendChild(td2);
                trow.appendChild(td3);
                trow.appendChild(td4);
                trow.appendChild(td5);
                trow.appendChild(td6);
                tbody.appendChild(trow);
            })
            document.getElementById("load").style.visibility="visible"
            latest=data.docs[data.docs.length-1]
            if(data.empty){
                document.getElementById("load").style.visibility="hidden"
            }
        }
    }
}
function load(){
    retrieveusers(1)
}