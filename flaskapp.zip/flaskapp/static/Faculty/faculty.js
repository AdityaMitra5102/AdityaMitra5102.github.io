var res=[]


function close_upload(){
  let hidden2=document.getElementById("Upload-Csv");
  hidden2.classList.toggle("Over_active")
  document.getElementById('UploadBar').innerHTML=""
  close_csv()
}

function upload_csv(){
  let hidden=document.getElementById("Upload-Csv");
  hidden.classList.toggle("Over_active")

  var bar = new ProgressBar.Circle(UploadBar, {
    color: '#000000',
    strokeWidth: 4,
    trailWidth: 1,
    easing: 'easeInOut',
    duration: 6000,
    text: {
      autoStyleContainer: false
    },
    svgStyle: {
      width: '300px',
      height:'300px'
      
  },
    from: { color: '#2E3192', width: 1 },
    to: { color: '#2E3192', width: 4 },
    step: function(state, circle) {
      circle.path.setAttribute('stroke', state.color);
      circle.path.setAttribute('stroke-width', state.width);
  
      var value = Math.round(circle.value() * 100);
      if (value === 0) {
        circle.setText('');
      } else {
        circle.setText(value+" %");
        if(value==100)
          { document.getElementById('close-csv').style.display="flex"
            document.getElementById('U-metadata').innerHTML="Details uploaded"
           
          }
      }
  
    }
  });
  
  bar.text.style.fontSize = '2rem';
  bar.animate(1.0);  
}

function uploadfile(){
    let file=document.getElementById('File').files[0]
    let progress=document.getElementsByClassName('progressbar')[0]
    let name=document.getElementById("filename")
    let size=document.getElementById("filesize")
    let csv_name=document.getElementById("csv_name")
    let newname=file.name
   
    document.getElementById('upload').style.display='none'
    progress.setAttribute("id","progress")
    if(newname.length>15)
        newname=newname.substring(0,15)+"..."
    name.innerHTML=newname
    size.innerHTML=(file.size/(1024*1024)).toFixed(2)+"MB"
    document.getElementsByClassName('main__container__wrapper')[0].style.display='none'
    document.getElementsByClassName('upload_container')[0].style.display='block'
    csv_name.innerHTML=file.name
    let T_body=document.getElementById('T_body');
  
    Papa.parse(file, {
        header:true,
        skipEmptyLines: true,
        complete: function(results) {
             T_body.innerHTML=""
            for(i=0;i<results.data.length;i++)
              {
                   let body=`<tr id=${i}>
                   <th scope="row">${i+1}</th>
                   <td><img src="../assets/img/img.svg" width="30" height="30" alt="Img"></td>
                   <td>${results.data[i].FullName}</td>
                   <td>${results.data[i].EmployeeID}</td>
                   <td>${results.data[i].Department}</td>
                   <td>${results.data[i].Email}</td>
                   <td><div class="Edit" onclick=OverActivtor(${i})><img src="../assets/img/pen.svg" alt="Edit" ></div></td>
                 </tr>`
                  T_body.innerHTML+=body
                  res.push(results.data[i])
              }
            
        }
    });
  
}

function OverActivtor(index){
  let hidden=document.getElementsByClassName("OverLay")[0];
  hidden.classList.toggle("Over_active")
  localStorage.setItem("lastclickedIndex", index);

  let img=document.getElementById("img_url")
  let name=document.getElementById("f_name")
  let e_id=document.getElementById("e_id")
  let Department=document.getElementById("Department")
  let email=document.getElementById("Email")

   img.value="../assets/img/img.svg"
   name.value=res[index].FullName
   e_id.value=res[index].EmployeeID
   Department.value=res[index].Department
   email.value=res[index].Email
}

function closeUpload(){
    document.getElementById('upload').style.display='flex'
    let progress=document.getElementsByClassName('progressbar')[0]
    progress.removeAttribute("id","progress")
     
  }

function close_csv(){
    let input=document.getElementById("File")
    input.onclick = function () {
        this.value = null;
      }
    document.getElementsByClassName('main__container__wrapper')[0].style.display='block'
    document.getElementsByClassName('upload_container')[0].style.display='none'
    document.getElementById('upload').style.display='flex'
    document.getElementsByClassName('progressbar')[0].style.display="none"

}

function save_f(){
  let hidden=document.getElementsByClassName("OverLay")[0];
  hidden.classList.toggle("Over_active")
  let index=localStorage.getItem("lastclickedIndex")
  console.log(index)
  let img=document.getElementById("img_url")
  let name=document.getElementById("f_name")
  let e_id=document.getElementById("e_id")
  let Department=document.getElementById("Department")
  let email=document.getElementById("Email")
  let ele=document.getElementById(index)
  let td=ele.getElementsByTagName("td")
  for(i=0;i<td.length;i++){
      if(i==0)
        td[i].innerHTML=`<td><img src="${img.value}" width="30" height="30" alt="Img"></td>`
      if(i==1)
        td[i].innerHTML=`<td>${name.value}</td>`
      if(i==2)
        td[i].innerHTML=`<td>${e_id.value}</td>`
      if(i==3)
        td[i].innerHTML=`<td>${Department.value}</td>`
      if(i==4)
        td[i].innerHTML=`<td>${email.value}</td>` 
  }
  console.log(res)
  //updating res value ---> send to ur api 

  res[index].Picture=img.value
  res[index].FullName=name.value
  res[index].EmployeeID=e_id.value
  res[index].Department=Department.value
  res[index].Email=email.value
  //updated value
  console.log(res[index])

}