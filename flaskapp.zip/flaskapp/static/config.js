// var config = {
//     apiKey: "AIzaSyBz9kDNQmC8L_hcI19pzTZWi7qTSv7IPQU",
//     authDomain: "mukham-core.firebaseapp.com",
//     databaseURL: "https://mukham-core.firebaseio.com",
//     projectId: "mukham-core",
//     storageBucket: "mukham-core.appspot.com",
//     messagingSenderId: "718343636245",
//     appId: "1:718343636245:web:756407f9f77ccba4aa951c",
//     measurementId: "G-M5Q57DQP9C"
// };
var config = {
    apiKey: "AIzaSyBexJb_2s5P3z96b75fU2jhZA8MQAMyuHQ",
    authDomain: "mukhamapp.firebaseapp.com",
    databaseURL: "https://mukhamapp-default-rtdb.firebaseio.com",
    projectId: "mukhamapp",
    storageBucket: "mukhamapp.appspot.com",
    messagingSenderId: "1017209631493",
    appId: "1:1017209631493:web:e6eeb49be5c6eadf05fd6c",
    measurementId: "G-BNW6S09C1F"
  };
  
firebase.initializeApp(config);