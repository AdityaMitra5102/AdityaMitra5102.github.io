function WriteMessage(){
  let header=document.getElementById('Announcement')
  let accoun=document.getElementsByClassName('flexcol');
  let hidden =document.getElementsByClassName('unhide');
  if(header.innerText=='Announcements'){
  header.innerHTML='New Message'
  for(i =0;i<accoun.length;i++)
   accoun[i].style.display ='none';
  hidden[0].style.display='block';
  }
  else{
    header.innerHTML="Announcements"
    for(i =0;i<accoun.length;i++)
     accoun[i].style.display ='block';
    hidden[0].style.display='none';
  }

}

function datasubmit(){
   
 let file=document.getElementById('File').files[0]
 let progress=document.getElementsByClassName('progressbar')[0]
 let name=document.getElementById("filename")
 let size=document.getElementById("filesize")
 let newname=file.name

 document.getElementById('upload').style.display='none'
 progress.setAttribute("id","progress")
 if(newname.length>15)
     newname=newname.substring(0,15)+"..."
 name.innerHTML=newname
 size.innerHTML=(file.size/(1024*1024)).toFixed(2)+"MB"

}


function closeUpload(){
  document.getElementById('upload').style.display='flex'
  let progress=document.getElementsByClassName('progressbar')[0]
  progress.removeAttribute("id","progress")
}