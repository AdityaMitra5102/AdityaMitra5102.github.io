var content='';
var content2='';
const form=document.querySelector("#messageform");
// const firebaseConfig = {
//     apiKey: "AIzaSyBz9kDNQmC8L_hcI19pzTZWi7qTSv7IPQU",
//     authDomain: "mukham-core.firebaseapp.com",
//     projectId: "mukham-core",
//     storageBucket: "mukham-core.appspot.com",
//     messagingSenderId: "718343636245",
//     appId: "1:718343636245:web:756407f9f77ccba4aa951c",
//     measurementId: "G-M5Q57DQP9C"
//   };
var firebaseConfig = {
  apiKey: "AIzaSyBexJb_2s5P3z96b75fU2jhZA8MQAMyuHQ",
  authDomain: "mukhamapp.firebaseapp.com",
  databaseURL: "https://mukhamapp-default-rtdb.firebaseio.com",
  projectId: "mukhamapp",
  storageBucket: "mukhamapp.appspot.com",
  messagingSenderId: "1017209631493",
  appId: "1:1017209631493:web:e6eeb49be5c6eadf05fd6c",
  measurementId: "G-BNW6S09C1F"
};
firebase.initializeApp(firebaseConfig);
var files=[];
const db = firebase.firestore();
const auth = firebase.auth()
auth.onAuthStateChanged((user)=> {
    if(!user) {
        window.location.href="../index.html"
    }else{
        user.providerData.forEach((profile) => {
            email=profile.uid;
            db.collection('Admins').where("emailid","==",email).get().then((snapshot)=>{
                snapshot.docs.forEach(doc =>{
                    document.getElementById("loginuser").innerHTML=doc.data().fullName;
                    document.getElementById("loginid").innerHTML="EmpId: "+doc.data().empid;
                })
            })
        })
    }
})
function logout(){
    const auth = firebase.auth()
    auth.signOut()
    window.location.href="./index.html"
}



db.settings({timestampInSnapshots: true},{merge: true});
function render(doc){
    console.log(doc);
    content+=" <div class='card__text row bgNotification' ><div class='col-md-6'><div>Faculty Name :</div>";
    content+="<div>Employee ID :</div><div>Department :</div><div >Reason :</div><div>Duration :</div><div>Total :</div><div>Attached Docx:</div></div>";
    content+="<div class='col-md-5'><div>"+doc.data().facultyname+"</div><div>"+doc.data().Employeeid+"</div><div>"+doc.data().Department+"</div><div>"+doc.data().Reason+"</div><div class='shiftDate'>"+doc.data().Duration+"</div><div>3 days</div><div> <a href="+doc.data().File+">receipt.pdf</a> </div><div class='shiftButton'><button type='button' class='btn btn-outline-primary'>Decline</button><button type='button' class='btn btn-primary'>Accept</button></div></div></div>";
}
db.collection('Leave').get().then((snapshot)=>{
    snapshot.docs.forEach(doc =>{
        render(doc);
    })
    document.getElementById('leaverow').innerHTML=""
                  $('#leaverow').append(content);

})
function render2(doc){
    console.log(doc);
    var tt=doc.data().upload;
    console.log(tt);
    content2+=" <div class='card__text row bgNotification flexcol'><div class='AnnounHeader'>"+doc.data().subject+"</div> <div class='AnnounText'><p>"+doc.data().content+"</p></div><div class='AnnounImg'><img src="+doc.data().imagefile+"  alt='Image' ></div><div class='Time'> <i class='bx bx-time-five'>"+tt+"</i> </div></div>";
}
db.collection('Announcements').get().then((snapshot)=>{
    snapshot.docs.forEach(doc =>{
        render2(doc);
    })
    document.getElementById('messagebox').innerHTML=""
                  $('#messagebox').append(content2);

})
var current = new Date();
const tt=current.toLocaleString();
var storage = firebase.app().storage("gs://mukham-core.appspot.com");
async function submit(){
    var validurl;
    const ref = firebase.storage().ref();
    const file = document.querySelector("#photo").files[0];
    const name = +new Date() + "-" + file.name;
    const metadata = {
      contentType: file.type
    };
    const task = ref.child(name).put(file, metadata);
    task
      .then(snapshot => snapshot.ref.getDownloadURL())
      .then(url => {
          validurl=url;
        console.log(url);
        db.collection("Announcements").add({
            'subject':form.subject.value,
            'content':form.content.value,
            'imagefile':validurl,
            'upload':current.toLocaleString(),
         })
         alert("sucess");
        document.querySelector("#image").src = url;
      })
      .catch(console.error);
    
}

