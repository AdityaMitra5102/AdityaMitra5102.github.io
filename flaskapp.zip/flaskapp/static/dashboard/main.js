/*===== SHOW NAVBAR  =====*/
const showNavbar = (toggleId, navId, bodyId, headerId) => {
    const toggle = document.getElementById(toggleId),
        nav = document.getElementById(navId),
        bodypd = document.getElementById(bodyId),
        headerpd = document.getElementById(headerId)

    // Validate that all variables exist
    if (toggle && nav && bodypd && headerpd) {
        toggle.addEventListener('click', () => {
            // show navbar
            nav.classList.toggle('show')
                // change icon
            toggle.classList.toggle('bx-x')
                // add padding to body
            bodypd.classList.toggle('body-pd')
                // add padding to header
            headerpd.classList.toggle('body-pd')
        })
    }
}

// function showNavbarWithoutClick(toggleId, navId, bodyId, headerId) {
//     toggle = document.getElementById(toggleId)
//     nav = document.getElementById(navId)
//     bodypd = document.getElementById(bodyId)
//     headerpd = document.getElementById(headerId)
//     nav.classList.toggle('show')
//         // change icon
//     toggle.classList.toggle('bx-x')
//         // add padding to body
//     bodypd.classList.toggle('body-pd')
//         // add padding to header
//     headerpd.classList.toggle('body-pd')
// }
// if (screen.width > 1100) {
//     console.log("inside");
//     showNavbarWithoutClick('header-toggle', 'nav-bar', 'body-pd', 'header');
// }
showNavbar('header-toggle', 'nav-bar', 'body-pd', 'header')

/*===== LINK ACTIVE  =====*/
const linkColor = document.querySelectorAll('.nav__link')

function colorLink() {
    if (linkColor) {
        linkColor.forEach(l => l.classList.remove('active'))
        this.classList.add('active')
    }
}
linkColor.forEach(l => l.addEventListener('click', colorLink))



function retrieveusers(){
    document.getElementById("tb1").innerHTML="";
    var present=0,absent=0;
    var year=document.getElementById("year").value;
    var month=document.getElementById("month").value;
    var count=1;
    if(year =="" || month==""){
        alert("Select proper year and month")
    }else{
        db.collection('Department').get().then(snapshot => {
            snapshot.forEach(doc => {
                var docRef1=db.collection("Department").doc(doc.id).collection("Years").doc(year).collection("Months").doc(month)
                docRef1.get().then(snapshot1=>{
                    var tbody=document.getElementById("tb1");
                    var trow=document.createElement('tr');
                    var td1=document.createElement('td');
                    var td2=document.createElement('td');
                    var td3=document.createElement('td');
                    var td4=document.createElement('td');
                    var td5=document.createElement('td');
                    var td6=document.createElement('td');
        
                    td1.innerHTML=count++;
                    td2.innerHTML=doc.id;
                    td3.innerHTML=snapshot1.data().Present;
                    td4.innerHTML=snapshot1.data().Absent;
                    td5.innerHTML=snapshot1.data().Total;
    
                    var percent=(snapshot1.data().Present/snapshot1.data().Total)*100;
                    percent=percent.toFixed(2)
                    myChart.data.datasets[0].data[count-2]=percent;
                    myChart.update();
                    td6.innerHTML=percent+"%";
    
                    present=present+parseInt(snapshot1.data().Present);
                    absent=absent+parseInt(snapshot1.data().Absent);
                    console.log(present+" "+absent)
                    myChart2.data.datasets[0].data[1]=present;
                    myChart2.data.datasets[0].data[0]=absent;
                    myChart2.update();
    
                    trow.appendChild(td1);
                    trow.appendChild(td2);
                    trow.appendChild(td3);
                    trow.appendChild(td4);
                    trow.appendChild(td5);
                    trow.appendChild(td6);
                    tbody.appendChild(trow);
                })
            })
        })
    }
}


const ctx = document.getElementById('myChart').getContext('2d');
const myChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: ['OTHERS', 'SCOPE', 'SENSE', 'VISH'],
        datasets: [{
            label: '# of Attendance',
            data: [0,0,0,0],
            backgroundColor: [
                'rgba(136, 191, 222, 1)',
                'rgba(136, 191, 222, 1)',
                'rgba(136, 191, 222, 1)',
                'rgba(136, 191, 222, 1)'
            ],
            borderColor: [
                'rgba(136, 191, 222, 1)',
                'rgba(136, 191, 222, 1)',
                'rgba(136, 191, 222, 1)',
                'rgba(136, 191, 222, 1)',
            ],
            borderWidth: 1,
        }]
    },
    options: {
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});
Chart.defaults.elements.bar.borderRadius = 10;

const plugin = {
    id: 'custom_canvas_background_image',
    beforeDraw: (chart) => {
        const ctx = chart.ctx;
        const { top, left, width, height } = chart.chartArea;
    }
};

const ctx2 = document.getElementById('myChart2').getContext('2d');
const myChart2 = new Chart(ctx2, {
    type: 'doughnut',
    data: {
        labels: [
            'Not Attended',
            'Attended',
        ],
        datasets: [{
            label: 'My First Dataset',
            data: [0, 0],
            backgroundColor: [
                'rgba(46, 49, 146, 1)',
                'rgba(136, 191, 222, 1)',
            ],
            hoverOffset: 4
        }]
    },
    options: {
        maintainAspectRatio: false,
        scales: {
            y: {
                beginAtZero: true
            }
        }
    },
    plugins: [plugin]
});
myChart.canvas.parentNode.style.height = '80vh';
myChart2.canvas.parentNode.style.height = '80vh';