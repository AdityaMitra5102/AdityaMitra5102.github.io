/*===== SHOW NAVBAR  =====*/
const showNavbar = (toggleId, navId, bodyId, headerId) => {
    const toggle = document.getElementById(toggleId),
        nav = document.getElementById(navId),
        bodypd = document.getElementById(bodyId),
        headerpd = document.getElementById(headerId)

    // Validate that all variables exist
    if (toggle && nav && bodypd && headerpd) {
        toggle.addEventListener('click', () => {
            // show navbar
            nav.classList.toggle('show')
            // Document.getElementById('nav_logo').style.marginleft="0";
            // Document.getElementById('nav_logo').style.marginright="0";
            // Document.getElementById('nav_logo').style.marginbottom="2rem";
                // change icon
            toggle.classList.toggle('bx-x')
                // add padding to body
            bodypd.classList.toggle('body-pd')
                // add padding to header
            headerpd.classList.toggle('body-pd')
        })
    }
}

// function showNavbarWithoutClick(toggleId, navId, bodyId, headerId) {
//     toggle = document.getElementById(toggleId)
//     nav = document.getElementById(navId)
//     bodypd = document.getElementById(bodyId)
//     headerpd = document.getElementById(headerId)
//     nav.classList.toggle('show')
//         // change icon
//     toggle.classList.toggle('bx-x')
//         // add padding to body
//     bodypd.classList.toggle('body-pd')
//         // add padding to header
//     headerpd.classList.toggle('body-pd')
// }
// if (screen.width > 1100) {
//     console.log("inside");
//     showNavbarWithoutClick('header-toggle', 'nav-bar', 'body-pd', 'header');
// }
showNavbar('header-toggle', 'nav-bar', 'body-pd', 'header')

/*===== LINK ACTIVE  =====*/
const linkColor = document.querySelectorAll('.nav__link')

function colorLink() {
    if (linkColor) {
        linkColor.forEach(l => l.classList.remove('active'))
        this.classList.add('active')
    }
}
linkColor.forEach(l => l.addEventListener('click', colorLink))